# ArcoBASIC Systems Language: UEFI x86-64 Target

This is the entry point for the ArcoBASIC systems-language milestone: compiling a restricted,
freestanding subset of ArcoBASIC directly into a bootable UEFI x86-64 application, with no C, C++,
Rust, or handwritten assembly anywhere in the application's own source. It exists so the project is
usable without the agent that built it (Packet WP-012 "Leave the project usable without the
agent"). Each linked document below covers one piece in full depth, verified against primary
sources and real hardware/firmware where that mattered; this page is the map.

```text
arcology-os/docs/systems/uefi-target.md          Target identity, directives, types, ABI, PE/COFF strategy (RFC)
arcology-os/docs/systems/calling-conventions.md  Microsoft x64 argument/return registers, shadow space, alignment
arcology-os/docs/systems/uefi-bindings.md        EFI_SYSTEM_TABLE/EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL field offsets
arcology-os/docs/systems/utf16-encoding.md       UTF-8 -> null-terminated UTF-16 constant encoding
arcology-os/docs/systems/x86-64-codegen.md       The instruction encoder and single-function code generator
arcology-os/docs/systems/pe32-image.md           The PE32+ writer, including the RELOCS_STRIPPED pitfall
arcology-os/docs/systems/qemu-ovmf-harness.md    The reusable QEMU/OVMF boot-and-verify harness
arcology-os/docs/systems/frontend-amir-contract.md  Authoritative AST -> A-MIR compiler contract
arcology-os/docs/systems/hardware-semantics.md   CPU.Halt and CPU.HaltForever semantics/lowering
arcology-os/docs/systems/port-io-semantics.md    Typed x86 port I/O and COM1 milestone
arcology-os/docs/systems/graphics-foundation.md  Surface renderer, clipped primitives, text, UI, and backbuffer contract
arcology-os/docs/systems/arcology-hardware-bringup.md  Reproducible USB image and hardware checklist
```

`.agents/reports/` holds one completion report per work package (`WP-000-repository-audit.md`
through `WP-011-end-to-end-milestone.md`), each with a `TESTS RUN`/`ACCEPTANCE CRITERIA`/`RISKS`
section, plus `systems-language-milestone-report.md`, the overarching summary against the Packet's
full Definition of Done.

## Prerequisites

To build ArcoBASIC/ArcoFission itself and run everything except the real firmware boot check:

- A C++17 compiler and CMake >= 3.16 (the only prerequisites this project has ever had).

To also run the real QEMU/OVMF boot check (`arcology-os/scripts/run/run-uefi-hello.sh`,
`arcology-os/tests/systems/systems_qemu_ovmf_harness_smoke.sh`):

- `qemu-system-x86_64` (Debian/Ubuntu: `apt install qemu-system-x86`; Fedora:
  `dnf install qemu-system-x86`; Arch: `pacman -S qemu-system-x86`)
- An OVMF UEFI firmware image under `/usr/share/ovmf` or `/usr/share/OVMF` (Debian/Ubuntu:
  `apt install ovmf`; Fedora: `dnf install edk2-ovmf`; Arch: `pacman -S edk2-ovmf`)

Neither is required to build ArcoFission or to compile a `.efi` file -- only to actually boot one.
If either is missing, `arcology-os/scripts/run/run-uefi-hello.sh` prints the exact install command and exits
nonzero; it never downloads anything automatically (arcology-os/docs/systems/qemu-ovmf-harness.md).

`nasm`, `objdump`, and Python's `pefile` were used during development to independently verify the
instruction encoder and PE writer against ground truth from tools that don't share this project's
own reasoning. **None of them are required** to build, test, or use ArcoFission -- they were
verification aids, not dependencies (arcology-os/docs/systems/x86-64-codegen.md, arcology-os/docs/systems/pe32-image.md).

Python 3 is required only by `arcology-os/scripts/build/build-arcology-hardware-image.py`, which serializes the
deterministic FAT32 USB image without depending on host filesystem-formatting utilities.

## Build Commands

```sh
cmake -S . -B build
cmake --build build -j"$(nproc)"
```

Then, to compile an ArcoBASIC systems program into a bootable UEFI application:

```sh
build/ArcoFission build arcology-os/tests/fixtures/uefi-hello/hello.abas -o hello.efi --target uefi-x86_64
```

`--target uefi-x86_64` is the only value this milestone supports; omitting it preserves
ArcoFission's existing (unrelated) Linux ELF64 bytecode-capsule build path exactly as before this
mission started. An optional `--entry NAME` selects which declared `FUNCTION` becomes the image's
entry point (default `Main`).

## Test Commands

```sh
cd build && ctest --output-on-failure
```

Runs every test, including the systems-specific ones added by this mission
(`systems_fixed_width_types_smoke`, `systems_freestanding_profile_smoke`,
`systems_amir_primitives_smoke`, `systems_calling_convention_smoke`, `systems_uefi_bindings_smoke`,
`systems_utf16_encoding_smoke`, `systems_x86_64_codegen_smoke`, `systems_pe_image_smoke`,
`systems_qemu_ovmf_harness_smoke`, `systems_frontend_amir_contract_smoke`,
`systems_hardware_semantics_smoke`, `systems_arcology_hardware_artifact_smoke`, and
`systems_port_io_smoke`). Firmware tests
skip gracefully (not a failure) if QEMU/OVMF are not installed. To run only the systems tests:

```sh
ctest --output-on-failure -R '^systems_'
```

To boot a built image directly, outside the test suite:

```sh
arcology-os/scripts/run/run-uefi-hello.sh hello.efi "Hello from ArcoBASIC"
```

To build and boot-test Packet 002's USB-ready Arcology Seed artifact:

```sh
arcology-os/scripts/build/build-arcology-hardware-artifact.sh
arcology-os/scripts/run/run-arcology-hardware-image.sh arcology-os/dist/arcology-seed-0.1/arcology-seed-0.1-x86_64.img
```

## Target Syntax

The exact, complete hello-world program (`arcology-os/tests/fixtures/uefi-hello/hello.abas`,
`arcology-os/examples/uefi_hello.abas`):

```basic
#PROFILE UEFI
#TARGET X86_64
#RUNTIME NONE
#CALLCONV UEFI
#EXPORT "efi_main"

FUNCTION Main(imageHandle AS UEFI.Handle, systemTable AS UEFI.SystemTable) AS U64
    systemTable.ConsoleOut.Write("Hello from ArcoBASIC")
    RETURN 0
END FUNCTION
```

- `#PROFILE UEFI` -- selects the systems profile. Only `UEFI` is accepted.
- `#TARGET X86_64` -- selects the architecture. Only `X86_64` is accepted. (`#TARGET` is an
  existing directive, extended for this meaning under a systems profile; see
  `arcology-os/docs/systems/uefi-target.md` section 2.)
- `#RUNTIME NONE` -- disables the hosted interpreter runtime; see "Unsupported Features" below for
  what this rules out.
- `#CALLCONV UEFI` -- selects the Microsoft x64 calling convention for the entry point.
- `#EXPORT "efi_main"` -- names the PE export symbol (informational at this stage; the PE writer
  always places the entry point at the start of `.text` regardless of the declared function name).
- `LET name AS Type = literal` -- typed local declarations, with compile-time range checking for
  the ten fixed-width types (`U8`/`U16`/`U32`/`U64`/`I8`/`I16`/`I32`/`I64`/`BOOL`/`PTR`).
- `UEFI.Handle`, `UEFI.SystemTable`, `UEFI.SystemTable.ConsoleOut`,
  `UEFI.SimpleTextOutputProtocol.Write` -- the bound UEFI surface (see below).

## Supported Systems Features

- Fixed-width integer/pointer types with exact-integer literal range checking
  (`arcology-os/docs/systems/uefi-target.md` section 3).
- The freestanding profile, rejecting hosted-runtime constructs (`PRINT`,
  `File.`/`Network.`/`System.`/etc. calls) with clear diagnostics when used under `#RUNTIME NONE`
  (`arcology-os/docs/systems/uefi-target.md` section 7).
- A-MIR representation of external/ABI-bound calls, distinct from ordinary host/stdlib calls
  (`.agents/reports/WP-004-amir-systems-primitives.md`).
- A canonical compiler-facing AST consumed directly by A-MIR lowering; the compiler no longer
  reparses the token stream (`arcology-os/docs/systems/frontend-amir-contract.md`).
- The Microsoft x64 calling convention, including automatic injection of the implicit `This`
  argument real UEFI protocol methods require (`arcology-os/docs/systems/x86-64-codegen.md`).
- `UEFI.SystemTable.ConsoleOut` (`EFI_SYSTEM_TABLE.ConOut`, offset `0x40`) and
  `UEFI.SimpleTextOutputProtocol.Write` (`EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL.OutputString`, offset
  `0x08`), verified against the TianoCore EDK2 reference headers (`arcology-os/docs/systems/uefi-bindings.md`).
- `UEFI.SystemTable.BootServices.SetWatchdogTimer` at offsets `0x60` then `0x100`, used narrowly to
  disable the firmware watchdog before the intentional hardware-test halt.
- `UEFI.SystemTable.BootServices.ExitBootServices` at offset `0xE8`, exposed for lifecycle
  handoff validation; acquiring a valid memory-map key remains future bootstrap work.
- Raw `GetMemoryMap`, `AllocatePool`, and `FreePool` service entries are registered at `0x38`,
  `0x40`, and `0x48` for the forthcoming typed bootstrap wrapper.
- Architecture-independent `CPU.Halt` and terminal `CPU.HaltForever` A-MIR operations, lowered by
  the x86-64 backend to `HLT` and `CLI; HLT; JMP -3` respectively.
- Typed `IOPORT`, `PORT.Address`, `PORT.Offset`, 8/16/32-bit `PORT.Read*`/`Write*` operations,
  intent aliases, and `CPU.Pause`, lowered directly to x86 `IN`, `OUT`, and `PAUSE` instructions.
- UTF-16 string constant encoding with correct surrogate-pair handling
  (`arcology-os/docs/systems/utf16-encoding.md`).
- A spill-based multi-block x86-64 code generator (prologue/epilogue, uniform value handling,
  UEFI field dereferencing, indirect calls, deterministic rel32 branches) producing machine code independently verified against
  `nasm` and `objdump` (`arcology-os/docs/systems/x86-64-codegen.md`).
- A self-contained PE32+ writer producing images that boot under real QEMU/OVMF
  (`arcology-os/docs/systems/pe32-image.md`).
- `ArcoFission reveal FILE at {AST|A-MIR|BYTECODE|CALLCONV|X86_64}` -- every compiler stage is
  independently inspectable.

## Unsupported Features (Non-Goals, Not Gaps to Silently Assume Away)

- **Control flow**: `IF ... END IF` (including `ELSE`) and `WHILE ... WEND` are supported with
  explicit A-MIR blocks and rel32 branch fixups. `ELSEIF` is not currently represented by the
  shared parser; `FOR`, `TRY`, and other multi-block constructs remain unsupported.
- **Classes, arrays, objects** under `#RUNTIME NONE`: not rejected at parse time today (a
  documented, narrower-than-planned scope decision -- see `.agents/reports/
  WP-003-freestanding-profile.md` DEVIATIONS), but not lowered by the code generator either, so a
  program using them under `--target uefi-x86_64` fails at the X86_64 codegen stage.
- **UEFI binding surface**: only `ConsoleOut`/`Write`, `ExitBootServices`, and the narrow
  `BootServices`/`SetWatchdogTimer` chain are bound. Every other `EFI_SYSTEM_TABLE`
  field (`ConIn`, `RuntimeServices`, ...) and every other
  `EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL` method (`Reset`, `ClearScreen`, ...) is rejected with a
  diagnostic naming what is bound instead (`arcology-os/docs/systems/uefi-bindings.md`).
- **Port I/O**: direct x86 port access is limited to 8-, 16-, and 32-bit transfers through
  `IOPORT`; no 64-bit forms, bulk string I/O, MMIO, or other device APIs are defined.
- **Floating point, SIMD, interrupts, MMIO, page tables, DMA, PCI, USB, networking, multicore,
  ARM64, legacy BIOS**: out of scope for this milestone by design (Packet section 4).
- **5th+ function parameters** (stack-passed, beyond the four register-passed arguments): rejected
  with a clear error; the hello-world's two-parameter entry point never needs one
  (`arcology-os/docs/systems/x86-64-codegen.md`).
- **Real PE relocations**: the writer has no `.reloc` section; every address the code generator
  produces is RIP-relative by construction, so none is needed today, but a future program requiring
  an absolute address fixup is not supported yet (`arcology-os/docs/systems/pe32-image.md`).

## Troubleshooting

| Symptom | Meaning | See |
|---|---|---|
| `Unknown compilation profile: X` / `Unsupported architecture for the UEFI profile: X` | Only `#PROFILE UEFI` and `#TARGET X86_64` are accepted this milestone | `arcology-os/docs/systems/uefi-target.md` |
| `... is not available under #RUNTIME NONE` | A hosted-runtime construct (`PRINT`, `File.*`, etc.) was used in a freestanding program | `arcology-os/docs/systems/uefi-target.md` section 7 |
| `UEFI.SystemTable has no bound field or method "X" ... Bound fields: ConsoleOut, BootServices.` | Only the listed UEFI surface is bound; `X` is real UEFI but not implemented here, or not real at all | `arcology-os/docs/systems/uefi-bindings.md` |
| `string argument cannot be encoded as UTF-16: ...` | A string literal passed to a UEFI call had an embedded NUL byte or malformed UTF-8 | `arcology-os/docs/systems/utf16-encoding.md` |
| `ERROR: qemu-system-x86_64 was not found` / `no OVMF UEFI firmware image was found` | Install guidance is printed directly to stderr; nothing is downloaded automatically | `arcology-os/docs/systems/qemu-ovmf-harness.md` |
| `arco_runtime_tests` crashes only with an explicit `-DCMAKE_BUILD_TYPE=Release`/`RelWithDebInfo` build | A **pre-existing, unrelated** bug in `src/shell/arcosh.cpp`'s `Process.Exists`, confirmed present before this mission started; does not occur with the project's standard build configuration | `.agents/reports/WP-000-repository-audit.md` section 7b |
| `undefined bytecode local: X` when running a typed-parameter function through `compile-run`/`run` | A **pre-existing, unrelated** bytecode-VM parameter-binding bug; irrelevant to the `--target uefi-x86_64` path, which does not use the bytecode VM | `.agents/reports/WP-000-repository-audit.md` section 7a |

## Architecture Overview

```text
ArcoBASIC source (.abas)
        |
    Lexer + shared preprocessor (#PROFILE/#RUNTIME/#TARGET/#CALLCONV/#EXPORT handled here)
        |
    Parser -- builds the authoritative canonical AST and performs compile-time systems checks:
        |     fixed-width literal ranges, freestanding-profile rejections,
        |     UEFI field-chain resolution, UTF-16 constant validation
        |
        +-- (for `reveal ... at AST`: rendered directly from here)
        |
    AstAmirBuilder -- consumes that AST directly; it never receives or reinterprets lexer tokens
        |
        +-- A-MIR (typed function signatures, CallExternal for ABI-bound calls, ...)
        |
    generate_x86_64_function -- single-function, spill-based x86-64 lowering
        |
        +-- machine code (.text) + UTF-16 data (.rdata) + unpatched RIP-relative relocations
        |
    write_pe32plus_efi_image -- patches relocations, lays out a minimal PE32+ image
        |
        +-- a real, bootable .efi file
        |
    QEMU + OVMF (real UEFI firmware) -- boots it, runs it, "Hello from ArcoBASIC" appears
```

The existing (pre-mission) Linux ELF64 bytecode-capsule build path (`ArcoFission build FILE -o
OUT` without `--target`) is untouched and uses a completely different route (A-MIR -> bytecode ->
tree-walking VM, wrapped in an ELF64 launcher) -- it does not share any code with the path above
beyond the shared lexer, preprocessor, and parser-level validation.

## Generated Artifact Locations

| Command | Output |
|---|---|
| `cmake --build build` | executables plus `libarco_runtime.a`, `libarco_compiler.a`, `libarco_shell.a`, and `libarco_c_api.a` |
| `ArcoFission build FILE -o OUT.efi --target uefi-x86_64` | `OUT.efi`, wherever specified -- a self-contained PE32+ file; nothing else is written |
| `ArcoFission reveal FILE at X86_64` | printed to stdout only; no file is written (use shell redirection to save it) |
| `arcology-os/scripts/run/run-uefi-hello.sh` | no artifacts left behind -- its temporary FAT boot directory is created under `mktemp -d` and removed on exit, success or failure |
| `arcology-os/scripts/build/build-arcology-hardware-artifact.sh` | `arcology-os/dist/arcology-seed-0.1/{BOOTX64.EFI,arcology-seed-0.1-x86_64.img,SHA256SUMS}` |
